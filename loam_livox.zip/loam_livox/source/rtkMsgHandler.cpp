//
// Created by wxc on 2023/3/27.
//
/*
#include"ros/ros.h"
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <GeographicLib/LocalCartesian.hpp>
#include <tf/transform_broadcaster.h>
#include <Eigen/Dense>
#include "/home/wxc/loam_livox/devel/include/loam_livox/GPFPD.h"

ros::Publisher rtkDatePub;
ros::Publisher path_pub;
void rtkMsg_callback(const loam_livox::GPFPDConstPtr& msg){

    double z;
    double y;
    double x;
    Eigen::Matrix<double,3,1>matrix1;
    Eigen::Matrix<double,3,3>matrix2;
    Eigen::Matrix<double,3,3>matrix3;
    nav_msgs::Odometry odometry;
    //geometry_msgs::Quaternion q;

    double angle = ((msg->heading)*M_PI/180.0);

    ///调用地理信息库，解算经纬高到东北天坐标系下
    GeographicLib::LocalCartesian geo_converter;
    geo_converter.Reset(34.219,117.143,42.29);
    geo_converter.Forward(msg->latitude,msg->longitude,msg->altitude,x,y,z);
    matrix1<<x,y,z;
    matrix2<<cos(-M_PI/2), -sin(-M_PI/2), 0,
            sin(-M_PI/2), cos(-M_PI/2), 0,
            0, 0, 1;
    matrix3<<cos(angle), -sin(angle), 0,
            sin(angle), cos(angle), 0,
            0, 0, 1;
    matrix1=matrix2*matrix1;
    matrix1=matrix3*matrix1;
    x=matrix1[0];
    y=matrix1[1];
    z=matrix1[2];

    //q=tf::createQuaternionMsgFromRollPitchYaw((msg->roll)*M_PI/180.0, (msg->pitch)*M_PI/180.0,-((msg->heading)*M_PI/180.0)+angle);

    static tf::TransformBroadcaster br;
    tf::Transform transform;
    tf::Quaternion quaternion;
    transform.setOrigin(tf::Vector3 (x,y,z));
    quaternion.setRPY(msg->roll* M_PI/180.0, msg->pitch* M_PI/180.0,-(msg->heading* M_PI/180.0)+angle);
    transform.setRotation(quaternion);
    br.sendTransform(tf::StampedTransform(transform,odometry.header.stamp,"map","vehicle_frame"));

    odometry.pose.pose.position.x= x;
    odometry.pose.pose.position.y= y;
    odometry.pose.pose.position.z= z;
    odometry.pose.pose.orientation.x=quaternion.x();
    odometry.pose.pose.orientation.y=quaternion.y();
    odometry.pose.pose.orientation.z=quaternion.z();
    odometry.pose.pose.orientation.w=quaternion.w();
    odometry.header.frame_id="map";
    odometry.header.stamp=msg->header.stamp;
    rtkDatePub.publish(odometry);

    nav_msgs::Path path;
    geometry_msgs::PoseStamped path_;
    path_.header = odometry.header;
    path_.pose = odometry.pose.pose;
    path.header.stamp = odometry.header.stamp;
    path.header.frame_id="map";
    path.poses.push_back(path_);
    path_pub.publish(path);

    std::cout<<"x: "<<odometry.pose.pose.position.x<<std::endl;
    std::cout<<"w: "<<odometry.pose.pose.orientation.w<<std::endl;
    //std::cout<<msg->latitude<<std::endl;
    //std::cout<<msg->longitude<<std::endl;
    //std::cout<<msg->altitude<<std::endl;


}
int main(int argc,char** argv){
    ros::init(argc,argv,"rtkMsgHandle");
    ros::NodeHandle nh;
    rtkDatePub=nh.advertise<nav_msgs::Odometry>("rtkMsgHandled",10);
    path_pub = nh.advertise<nav_msgs::Path>("gpsTrack",10, true);
    ros::Subscriber sub1=nh.subscribe<loam_livox::GPFPD>("chatter",10,rtkMsg_callback);
    ros::spin();
    return 0;
}*/



/*解算rtk数据并发布path、odom和tf数据
 * */

#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include <std_msgs/Float32.h>
#include "/home/wxc/loam_livox/devel/include/loam_livox/GPFPD.h"
#include <GeographicLib/LocalCartesian.hpp> //包含头文件

#include "nav_msgs/Odometry.h"
#include <nav_msgs/Path.h>


#define PI 3.1415926
bool is_init=false;
double X,Y,Z;
double latitude,longitude,altitude;

ros::Publisher odom_pub;
ros::Publisher path_pub;
nav_msgs::Path rtk_path;
ros::Publisher pcl_pub;

tf::Quaternion q_NED_rtkinit;
double angle;

//my pub
void RTK_TF_callback(const loam_livox::GPFPDConstPtr& cur_info)
{
    tf::Quaternion q_enu_ned;
    tf::Quaternion q_rtkinit_enu; //
    q_enu_ned.setRPY(180*PI/180,0*PI/180,90*PI/180);
    //rtk的坐标系与rviz中默认坐标系差180度
    tf::Quaternion qq;
    qq.setRPY(180*PI/180,0*PI/180,0*PI/180);
    GeographicLib::LocalCartesian geo_converter;
    //初始化操作
    if(!is_init)
    {
        latitude=cur_info->latitude;
        longitude=cur_info->longitude;
        altitude=cur_info->altitude;

        q_NED_rtkinit = tf::createQuaternionFromRPY(((cur_info->roll)*PI)/180.0, ((cur_info->pitch)*PI)/180.0, ((cur_info->heading)*PI)/180.0);
        q_rtkinit_enu=(q_enu_ned*q_NED_rtkinit*qq).inverse();
        is_init=true;
    }

    geo_converter.Reset(latitude,longitude,altitude);  //以第一帧初始化地理坐标系
    geo_converter.Forward(cur_info->latitude, cur_info->longitude, cur_info->altitude, X, Y, Z);

    tf::Quaternion q_NED_rtk;
    tf::Quaternion q_rtkinit_rtk;


    q_NED_rtk.setRPY(((cur_info->roll)*PI)/180.0, ((cur_info->pitch)*PI)/180.0, ((cur_info->heading)*PI)/180.0);

    q_rtkinit_rtk=q_rtkinit_enu*q_enu_ned*q_NED_rtk*qq;

    tf::Transform transform_rtkinit_enu;
    transform_rtkinit_enu.setRotation(q_rtkinit_enu);

    tf::Vector3 cur_pose(X,Y,Z);
    cur_pose=transform_rtkinit_enu*cur_pose;
    //-----------------------------------------------------------------------------------------------------------------

    //发布TF  map --> rtk_base_link
    static tf::TransformBroadcaster br;
    tf::Transform transform;
    transform.setRotation(q_rtkinit_rtk);
    transform.setOrigin(cur_pose);
    br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "world","rtk_base_link"));

    //发布odom
    nav_msgs::Odometry rtkpose;
    rtkpose.header.stamp =ros::Time::now();
    rtkpose.pose.pose.position.x=cur_pose.getX(); //当前坐标系原点在map下的坐标
    rtkpose.pose.pose.position.y=cur_pose.getY();
    rtkpose.pose.pose.position.z=cur_pose.getZ();
    rtkpose.pose.pose.orientation.x=q_rtkinit_rtk.x(); //旋转多少角度可以回到map下,是以当前的坐标为参考，旋转多少可以回归到map下
    rtkpose.pose.pose.orientation.y=q_rtkinit_rtk.y();
    rtkpose.pose.pose.orientation.z=q_rtkinit_rtk.z();
    rtkpose.pose.pose.orientation.w=q_rtkinit_rtk.w();
    rtkpose.header.frame_id="world";
    rtkpose.child_frame_id="rtk_base_link";
    odom_pub.publish(rtkpose);

    //发布path
    rtk_path.header.frame_id ="world";
    rtk_path.header.stamp =ros::Time::now();
    geometry_msgs::PoseStamped pose;
    pose.header.stamp=rtkpose.header.stamp;
    pose.header.frame_id="world";
    pose.pose.position.x=rtkpose.pose.pose.position.x;
    pose.pose.position.y=rtkpose.pose.pose.position.y;
    pose.pose.position.z=rtkpose.pose.pose.position.z;
    pose.pose.orientation.x=rtkpose.pose.pose.orientation.x;
    pose.pose.orientation.y=rtkpose.pose.pose.orientation.y;
    pose.pose.orientation.z=rtkpose.pose.pose.orientation.z;
    pose.pose.orientation.w=rtkpose.pose.pose.orientation.w;
    rtk_path.poses.push_back(pose);
    path_pub.publish(rtk_path);
}

int main(int argc,char** argv)
{
    ros::init(argc,argv,"my_tf_broadcaster");
    ros::NodeHandle nh;
    ros::Subscriber sub2= nh.subscribe<loam_livox::GPFPD> ("/chatter", 100, RTK_TF_callback);
    odom_pub=nh.advertise<nav_msgs::Odometry>("/rtk_pose",100);
    path_pub=nh.advertise<nav_msgs::Path>("/rtk_path",100);

    ros::spin();
    return 0;
}