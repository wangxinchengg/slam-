//
// Created by wxc on 2023/3/26.
//

#include <iostream>
#include <string>
#include <fstream>
#include <ros/ros.h>
#include <nav_msgs/Odometry.h>

using namespace std;
string aft_mapped_to_init = "/home/wxc/loam_livox/src/loam_livox/odom_txt/rtk.txt";
fstream Aft_mapped_to_init;

void aft_mapped_handler(const nav_msgs::Odometry::ConstPtr& msgIn)
{
    nav_msgs::Odometry data = *msgIn;
    static int flag=1;
    static double stamp_init;
    if(flag==1){
        stamp_init = data.header.stamp.toSec();
        flag=0;
    }
    Aft_mapped_to_init << fixed << data.header.stamp.toSec()-stamp_init   << " "   << data.pose.pose.position.x    << " " << data.pose.pose.position.y << " "
                << data.pose.pose.position.z    << " "   << data.pose.pose.orientation.x << " " << data.pose.pose.orientation.y << " "
                << data.pose.pose.orientation.z << " " << data.pose.pose.orientation.w   << std::endl;

}


int main(int argc, char** argv)
{
    ros::init(argc, argv, "odom2txt");
    ros::NodeHandle nh;

    Aft_mapped_to_init .open(aft_mapped_to_init, ios::out);

    /// ros::TransportHints().tcpNoDelay()以这种机制传输时间较快
    ros::Subscriber sub_aft_mapped_to_init = nh.subscribe<nav_msgs::Odometry>("/rtk_pose", 1000, &aft_mapped_handler, ros::TransportHints().tcpNoDelay());

    ROS_INFO("\033[1;32m----> odom2txt start.\033[0m");
    ros::spin();

    return 0;
}

